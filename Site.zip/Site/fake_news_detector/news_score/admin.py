from django.contrib import admin
from .models import  news_url
# Register your models here.

admin.site.register(news_url)
