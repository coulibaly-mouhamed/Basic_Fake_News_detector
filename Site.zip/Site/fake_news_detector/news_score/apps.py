from django.apps import AppConfig


class NewsScoreConfig(AppConfig):
    name = 'news_score'
